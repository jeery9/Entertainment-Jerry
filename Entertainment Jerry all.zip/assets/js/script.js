// Entertainment Jerry - paginated placeholders (20 pages x 10 slots) with IndexedDB persistence and ZIP export
(() => {
  const PAGES = 20;
  const SLOTS = 10;
  const DB_NAME = 'entjerry-db';
  const STORE_NAME = 'files';

  const qs = s => document.querySelector(s);
  const qsa = s => Array.from(document.querySelectorAll(s));

  // State: for each tab we keep pages -> slots array
  const state = {
    audio: Array.from({length: PAGES}, () => Array.from({length: SLOTS}, () => null)),
    video: Array.from({length: PAGES}, () => Array.from({length: SLOTS}, () => null)),
    image: Array.from({length: PAGES}, () => Array.from({length: SLOTS}, () => null)),
  };

  let currentTab = 'audio';
  let currentPage = 0;

  // Elements
  const tabBtns = qsa('.tab-btn');
  const panels = qsa('.tab-panel');
  const paginationEl = qs('#pagination');
  const pageInfoEl = qs('#page-info');

  const audioGrid = qs('#audio-grid');
  const videoGrid = qs('#video-grid');
  const imageGrid = qs('#image-grid');

  const audioDrop = qs('#audio-drop');
  const videoDrop = qs('#video-drop');
  const imageDrop = qs('#image-drop');

  const modal = qs('#image-modal');
  const modalImage = qs('#modal-image');
  const modalCaption = qs('#modal-caption');
  const modalClose = qs('#modal-close');

  const videoPlayer = qs('#video-player');

  const exportBtn = qs('#export-zip');
  const clearAllBtn = qs('#clear-all');

  // -----------------------
  // IndexedDB helpers
  // -----------------------
  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function(e) {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' }); // id: `${tab}-${page}-${slot}`
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function dbPut(entry) {
    return openDb().then(db => new Promise((res, rej) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const r = store.put(entry);
      r.onsuccess = () => { db.close(); res(r.result); };
      r.onerror = () => { db.close(); rej(r.error); };
    }));
  }

  function dbGetAll() {
    return openDb().then(db => new Promise((res, rej) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const r = store.getAll();
      r.onsuccess = () => { db.close(); res(r.result || []); };
      r.onerror = () => { db.close(); rej(r.error); };
    }));
  }

  function dbDelete(id) {
    return openDb().then(db => new Promise((res, rej) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const r = store.delete(id);
      r.onsuccess = () => { db.close(); res(); };
      r.onerror = () => { db.close(); rej(r.error); };
    }));
  }

  function dbClearAll() {
    return openDb().then(db => new Promise((res, rej) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const r = store.clear();
      r.onsuccess = () => { db.close(); res(); };
      r.onerror = () => { db.close(); rej(r.error); };
    }));
  }

  // -----------------------
  // Build UI and behavior
  // -----------------------
  tabBtns.forEach(btn => btn.addEventListener('click', () => {
    tabBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const target = btn.dataset.target;
    panels.forEach(p => p.id === target ? p.classList.add('active') : p.classList.remove('active'));
    currentTab = target;
    render();
  }));

  // Build pagination
  function buildPagination() {
    paginationEl.innerHTML = '';
    for (let i = 0; i < PAGES; i++) {
      const btn = document.createElement('button');
      btn.className = 'page-btn';
      btn.textContent = (i+1);
      if (i === currentPage) btn.classList.add('active');
      btn.addEventListener('click', () => {
        currentPage = i;
        render();
      });
      paginationEl.appendChild(btn);
    }
    pageInfoEl.textContent = `Page ${currentPage+1} of ${PAGES}`;
  }

  // Helper: create slot element
  function createSlot(tab, pageIndex, slotIndex) {
    const container = document.createElement('div');
    container.className = 'slot';
    const head = document.createElement('div');
    head.className = 'slot-head';
    const title = document.createElement('div');
    title.textContent = `${tab.toUpperCase()} #${slotIndex+1}`;
    const actions = document.createElement('div');
    actions.className = 'slot-actions';

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.style.display = 'none';
    if (tab === 'audio') fileInput.accept = 'audio/*';
    if (tab === 'video') fileInput.accept = 'video/*';
    if (tab === 'image') fileInput.accept = 'image/*';

    const selectBtn = document.createElement('button');
    selectBtn.className = 'small';
    selectBtn.textContent = 'Select';
    selectBtn.addEventListener('click', () => fileInput.click());

    const clearBtn = document.createElement('button');
    clearBtn.className = 'small';
    clearBtn.textContent = 'Clear';
    clearBtn.addEventListener('click', async () => {
      const key = `${tab}-${pageIndex}-${slotIndex}`;
      const prev = state[tab][pageIndex][slotIndex];
      if (prev && prev._url) {
        try { URL.revokeObjectURL(prev._url); } catch(e){}
      }
      state[tab][pageIndex][slotIndex] = null;
      await dbDelete(key);
      render();
    });

    actions.appendChild(selectBtn);
    actions.appendChild(clearBtn);
    head.appendChild(title);
    head.appendChild(actions);

    const body = document.createElement('div');
    body.className = 'slot-body';

    // preview area
    const placeholder = document.createElement('div');
    placeholder.className = 'placeholder';
    placeholder.textContent = 'Empty';
    body.appendChild(placeholder);

    // drop handling for this slot
    container.addEventListener('dragover', (e) => { e.preventDefault(); container.classList.add('dragover'); });
    container.addEventListener('dragleave', () => { container.classList.remove('dragover'); });
    container.addEventListener('drop', (e) => {
      e.preventDefault();
      container.classList.remove('dragover');
      if (e.dataTransfer.files && e.dataTransfer.files.length) {
        const file = e.dataTransfer.files[0];
        assignFileToSlot(tab, pageIndex, slotIndex, file);
      }
    });

    // input change
    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length) {
        assignFileToSlot(tab, pageIndex, slotIndex, e.target.files[0]);
      }
    });

    // click body to open file selector
    body.addEventListener('click', () => fileInput.click());

    container.appendChild(head);
    container.appendChild(body);
    container.appendChild(fileInput);
    return container;
  }

  async function assignFileToSlot(tab, pageIndex, slotIndex, file) {
    // validate type
    if (tab === 'audio' && !file.type.startsWith('audio')) return alert('Please select an audio file.');
    if (tab === 'video' && !file.type.startsWith('video')) return alert('Please select a video file.');
    if (tab === 'image' && !file.type.startsWith('image')) return alert('Please select an image file.');

    // revoke previous
    const prev = state[tab][pageIndex][slotIndex];
    if (prev && prev._url) {
      try { URL.revokeObjectURL(prev._url); } catch(e){}
    }

    const blobUrl = URL.createObjectURL(file);
    // store minimal info in memory
    state[tab][pageIndex][slotIndex] = {
      name: file.name,
      size: file.size,
      type: file.type,
      _url: blobUrl
    };

    // store in IndexedDB (store the blob)
    const key = `${tab}-${pageIndex}-${slotIndex}`;
    try {
      await dbPut({
        id: key,
        tab,
        page: pageIndex,
        slot: slotIndex,
        name: file.name,
        type: file.type,
        size: file.size,
        blob: file // store File/Blob directly
      });
    } catch (err) {
      console.error('Failed to store file in IndexedDB', err);
      alert('Warning: failed to persist file locally. It will still work this session.');
    }

    render();
  }

  // Fill first empty slots with dropped file list
  function fillEmptySlotsWithFiles(tab, pageIndex, files) {
    const arr = Array.from(files);
    let slotIdx = 0;
    for (let f of arr) {
      // find next empty slot
      while (slotIdx < SLOTS && state[tab][pageIndex][slotIdx]) slotIdx++;
      if (slotIdx >= SLOTS) break;
      // validate type
      if ((tab === 'audio' && !f.type.startsWith('audio')) ||
          (tab === 'video' && !f.type.startsWith('video')) ||
          (tab === 'image' && !f.type.startsWith('image'))) {
        // skip invalid
        continue;
      }
      assignFileToSlot(tab, pageIndex, slotIdx, f);
      slotIdx++;
    }
  }

  // Render current page & tab
  function render() {
    // update pagination highlights
    buildPagination();

    // clear grids
    audioGrid.innerHTML = '';
    videoGrid.innerHTML = '';
    imageGrid.innerHTML = '';

    // render slots for each tab
    for (let i = 0; i < SLOTS; i++) {
      // audio slot
      const audioSlotEl = createSlot('audio', currentPage, i);
      const aData = state.audio[currentPage][i];
      const aBody = audioSlotEl.querySelector('.slot-body');
      if (aData) {
        aBody.innerHTML = '';
        const meta = document.createElement('div');
        meta.className = 'meta';
        const name = document.createElement('div'); name.textContent = aData.name;
        name.className = 'name';
        const size = document.createElement('div'); size.textContent = `${(aData.size/1024/1024).toFixed(2)} MB`; size.className = 'sub';
        meta.appendChild(name); meta.appendChild(size);
        const audio = document.createElement('audio'); audio.controls = true; audio.src = aData._url; audio.preload = 'metadata';
        aBody.appendChild(meta);
        aBody.appendChild(audio);
      }
      audioGrid.appendChild(audioSlotEl);

      // video slot
      const videoSlotEl = createSlot('video', currentPage, i);
      const vData = state.video[currentPage][i];
      const vBody = videoSlotEl.querySelector('.slot-body');
      if (vData) {
        vBody.innerHTML = '';
        const meta = document.createElement('div');
        const name = document.createElement('div'); name.textContent = vData.name; name.className = 'name';
        meta.appendChild(name);
        const playBtn = document.createElement('button'); playBtn.className = 'btn'; playBtn.textContent = 'Play in player';
        playBtn.addEventListener('click', () => {
          // play in main player
          if (videoPlayer.src) { try { URL.revokeObjectURL(videoPlayer.src); } catch(e){} }
          videoPlayer.src = vData._url;
          videoPlayer.play();
        });
        vBody.appendChild(meta);
        vBody.appendChild(playBtn);
      }
      videoGrid.appendChild(videoSlotEl);

      // image slot
      const imageSlotEl = createSlot('image', currentPage, i);
      const imgData = state.image[currentPage][i];
      const imgBody = imageSlotEl.querySelector('.slot-body');
      if (imgData) {
        imgBody.innerHTML = '';
        const img = document.createElement('img');
        img.src = imgData._url;
        img.alt = imgData.name;
        img.style.cursor = 'pointer';
        img.addEventListener('click', () => openModal(imgData._url, imgData.name));
        imgBody.appendChild(img);
      }
      imageGrid.appendChild(imageSlotEl);
    }

    // update page info
    pageInfoEl.textContent = `Page ${currentPage+1} of ${PAGES}`;
  }

  // Drag & drop handling for tab areas (fill empty slots)
  function setupTabDrop(areaEl, tab) {
    areaEl.addEventListener('dragover', (e) => { e.preventDefault(); areaEl.classList.add('dragover'); });
    areaEl.addEventListener('dragleave', () => { areaEl.classList.remove('dragover'); });
    areaEl.addEventListener('drop', (e) => {
      e.preventDefault();
      areaEl.classList.remove('dragover');
      if (e.dataTransfer.files && e.dataTransfer.files.length) {
        fillEmptySlotsWithFiles(tab, currentPage, e.dataTransfer.files);
      }
    });
    // clicking drop area will open file selector to fill next empty slots
    areaEl.addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      if (tab === 'audio') input.accept = 'audio/*';
      if (tab === 'video') input.accept = 'video/*';
      if (tab === 'image') input.accept = 'image/*';
      input.multiple = true;
      input.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length) {
          fillEmptySlotsWithFiles(tab, currentPage, e.target.files);
        }
      });
      input.click();
    });
  }

  // Modal
  function openModal(src, caption) {
    modalImage.src = src;
    modalCaption.textContent = caption || '';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
  function closeModal() {
    modal.setAttribute('aria-hidden', 'true');
    modalImage.src = '';
    document.body.style.overflow = '';
  }
  modalClose.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  // -----------------------
  // Persistence: load DB and populate state
  // -----------------------
  async function loadFromDb() {
    try {
      const entries = await dbGetAll();
      // entries: {id, tab, page, slot, name, type, size, blob}
      for (const e of entries) {
        if (!e.tab || e.page == null || e.slot == null) continue;
        try {
          const blob = e.blob;
          // create object URL
          const blobUrl = URL.createObjectURL(blob);
          state[e.tab][e.page][e.slot] = {
            name: e.name,
            size: e.size,
            type: e.type,
            _url: blobUrl
          };
        } catch (err) {
          console.warn('Failed to create object URL for stored file', err);
        }
      }
      render();
    } catch (err) {
      console.error('Failed to load stored files', err);
    }
  }

  // -----------------------
  // Export ZIP (uses JSZip loaded via CDN in index.html)
  // -----------------------
  async function exportZip() {
    if (typeof JSZip === 'undefined') {
      alert('JSZip library not loaded. Export unavailable.');
      return;
    }
    try {
      const entries = await dbGetAll();
      if (!entries.length) return alert('No stored files to export.');
      const zip = new JSZip();
      for (const e of entries) {
        // add file blob using stored blob
        zip.file(`${e.tab}/page-${String(e.page+1).padStart(2,'0')}/slot-${String(e.slot+1).padStart(2,'0')}-${e.name}`, e.blob);
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `entertainment-jerry-backup.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (err) {
      console.error('Export failed', err);
      alert('Export failed — see console for details.');
    }
  }

  // Clear all stored data (DB + in-memory state)
  async function clearAll() {
    if (!confirm('Clear all stored files in this browser? This cannot be undone.')) return;
    // revoke all object URLs
    for (const tab of ['audio','video','image']) {
      for (let p = 0; p < PAGES; p++) {
        for (let s = 0; s < SLOTS; s++) {
          const v = state[tab][p][s];
          if (v && v._url) {
            try { URL.revokeObjectURL(v._url); } catch(e){}
          }
          state[tab][p][s] = null;
        }
      }
    }
    await dbClearAll();
    render();
  }

  // initial setup
  setupTabDrop(audioDrop, 'audio');
  setupTabDrop(videoDrop, 'video');
  setupTabDrop(imageDrop, 'image');

  exportBtn.addEventListener('click', exportZip);
  clearAllBtn.addEventListener('click', clearAll);

  buildPagination();
  // load persisted files and render
  loadFromDb();

})();