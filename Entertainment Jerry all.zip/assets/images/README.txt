Save the background image here as: assets/images/headphones.jpg

Recommended image (royalty-free):
- Pexels page: https://www.pexels.com/photo/man-wearing-white-headphones-814508/
- Direct image URL (hotlink fallback used in CSS): https://images.pexels.com/photos/814508/pexels-photo-814508.jpeg

How to add:
1. Download the high-resolution image from the Pexels page (click "Free Download").
2. Create the folder assets/images/ if it doesn't exist.
3. Save the downloaded file as: headphones.jpg
   (full path: assets/images/headphones.jpg)

If you prefer not to download the image, the site will use the Pexels hotlink as a fallback (the CSS includes a fallback). For offline/off-hosting use, download and place the file locally as instructed.

Attribution (recommended, not required by Pexels):
Photo: "Man wearing white headphones" — Photo by Burst on Pexels
Pexels page: https://www.pexels.com/photo/man-wearing-white-headphones-814508/